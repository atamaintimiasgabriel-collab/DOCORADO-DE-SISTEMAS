import cv2 #Librería de visión por computadora muy usada para trabajar con imágenes, cámaras y procesamiento de video
           #Permite aplicar filtros, reconocer rostros, ojos, sonrisas y manejar cámara en tiempo real.

import numpy as np #Librería fundamental para trabajar con matrices y operaciones matemáticas.
                   #Se usa aquí para manipular pixeles e imágenes (que internamente son matrices).
                   
import time #Librería estándar de Python para manejar tiempo y fechas.
            #Se usa para ponerle sello de tiempo a las fotos guardadas.

# ==============================
# 📌 Función: Redimensionar imagen y centrarla en un lienzo con un borde animado
# ==============================
def centrar_imagen_con_borde(img, frame_count, ancho=600, alto=600, lienzo_size=800):
    """
    Redimensiona la imagen para ajustarse dentro de un cuadro definido
    y la coloca centrada en un lienzo con un borde arcoiris animado.
    
    Parámetros:
    - img: Imagen de entrada
    - frame_count: Número de frame actual (para animar el borde)
    - ancho, alto: Tamaño máximo de la imagen
    - lienzo_size: Tamaño total del lienzo cuadrado
    
    Retorna:
    - Imagen lista para mostrar en ventana
    """
    h, w = img.shape[:2]
    escala = min(ancho / w, alto / h)
    new_w, new_h = int(w * escala), int(h * escala)

    # Redimensionar la imagen
    img_resized = cv2.resize(img, (new_w, new_h))

    # Crear lienzo negro
    lienzo = np.zeros((lienzo_size, lienzo_size, 3), dtype=np.uint8)

    # Calcular offsets para centrar
    y_offset = (lienzo_size - new_h) // 2
    x_offset = (lienzo_size - new_w) // 2

    # Convertir a color si es en escala de grises
    if len(img_resized.shape) == 2:
        img_resized = cv2.cvtColor(img_resized, cv2.COLOR_GRAY2BGR)

    # Pegar imagen al lienzo
    lienzo[y_offset:y_offset+new_h, x_offset:x_offset+new_w] = img_resized

    # 🎨 Borde arcoiris animado usando senos
    color_r = int((np.sin(frame_count*0.1) + 1) * 127)
    color_g = int((np.sin(frame_count*0.13 + 2) + 1) * 127)
    color_b = int((np.sin(frame_count*0.15 + 4) + 1) * 127)
    borde_color = (color_b, color_g, color_r)

    # Dibujar el borde alrededor
    cv2.rectangle(lienzo, (x_offset-15, y_offset-15),
                  (x_offset+new_w+15, y_offset+new_h+15),
                  borde_color, 8)

    return lienzo

# ==============================
# 📌 Inicializar cámara
# ==============================
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("⚠️ Error: No se pudo acceder a la cámara.")
    exit()

# ==============================
# 📌 Detectores de rostros, ojos y sonrisas (Haar Cascades de OpenCV)
# ==============================
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')

# ==============================
# 📌 Filtros visuales "ULTRA"
# ==============================
def aplicar_filtro(frame, filtro):
    """
    Aplica diferentes filtros a la imagen de la cámara.
    """
    if filtro == "gris":
        return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    elif filtro == "rojo":
        rojo = frame.copy(); rojo[:,:,0]=0; rojo[:,:,1]=0; return rojo
    elif filtro == "verde":
        verde = frame.copy(); verde[:,:,0]=0; verde[:,:,2]=0; return verde
    elif filtro == "azul":
        azul = frame.copy(); azul[:,:,1]=0; azul[:,:,2]=0; return azul
    elif filtro == "sepia":
        sepia = cv2.transform(frame, np.matrix([[0.272,0.534,0.131],
                                                [0.349,0.686,0.168],
                                                [0.393,0.769,0.189]]))
        return np.clip(sepia, 0, 255).astype(np.uint8)
    elif filtro == "invertir":
        return cv2.bitwise_not(frame)
    elif filtro == "canny":
        return cv2.Canny(frame, 100, 200)
    elif filtro == "blur":
        return cv2.GaussianBlur(frame, (21,21), 0)
    elif filtro == "caricatura":
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.medianBlur(gray, 7)
        edges = cv2.adaptiveThreshold(gray, 255,
                                      cv2.ADAPTIVE_THRESH_MEAN_C,
                                      cv2.THRESH_BINARY, 9, 9)
        color = cv2.bilateralFilter(frame, 9, 300, 300)
        cartoon = cv2.bitwise_and(color, color, mask=edges)
        return cartoon
    elif filtro == "pixel":
        small = cv2.resize(frame, (80, 80), interpolation=cv2.INTER_LINEAR)
        return cv2.resize(small, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST)
    else:
        return frame

# ==============================
# 📌 Menú de opciones
# ==============================
print("📹 ULTRA PRO Cámara con Filtros y Detección:")
print("0 - Original")
print("1 - Escala de Grises")
print("2 - Rojo")
print("3 - Verde")
print("4 - Azul")
print("5 - Sepia")
print("6 - Invertir Colores")
print("7 - Bordes Canny")
print("8 - Blur Futurista")
print("9 - Caricatura")
print("p - Pixel Art")
print("s - Guardar foto")
print("q / ESC - Salir")

# ==============================
# 📌 Variables de control
# ==============================
filtro_actual = "original"
nombre_filtro = "Original"
frame_count = 0

# ==============================
# 📌 Bucle principal
# ==============================
while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame_count += 1

    # 🎯 Detectar rostros
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x,y,w,h) in faces:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,255),2)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = frame[y:y+h, x:x+w]

        # 👁 Detección de ojos
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex,ey,ew,eh) in eyes:
            cv2.circle(roi_color, (ex+ew//2, ey+eh//2), ew//3, (255,0,0), 2)

        # 😀 Detección de sonrisas
        smiles = smile_cascade.detectMultiScale(roi_gray,1.7,22)
        for (sx,sy,sw,sh) in smiles:
            cv2.rectangle(roi_color,(sx,sy),(sx+sw,sy+sh),(0,255,0),2)

    # 🔴 Escáner láser futurista
    h, w = frame.shape[:2]
    line_y = (frame_count*5) % h
    cv2.line(frame, (0,line_y), (w,line_y), (0,0,255), 2)

    # Aplicar filtro actual
    frame_filtrado = aplicar_filtro(frame, filtro_actual)

    # Centrar imagen en lienzo con borde animado
    img_mostrar = centrar_imagen_con_borde(frame_filtrado, frame_count)

    # Mostrar en ventana
    cv2.imshow("🚀 ULTRA PRO Cam - HUD Futurista", img_mostrar)

    # ==============================
    # 📌 Teclado: manejo de opciones
    # ==============================
    tecla = cv2.waitKey(1) & 0xFF
    if tecla == ord('0'): filtro_actual, nombre_filtro = "original","Original"
    elif tecla == ord('1'): filtro_actual, nombre_filtro = "gris","Gris"
    elif tecla == ord('2'): filtro_actual, nombre_filtro = "rojo","Rojo"
    elif tecla == ord('3'): filtro_actual, nombre_filtro = "verde","Verde"
    elif tecla == ord('4'): filtro_actual, nombre_filtro = "azul","Azul"
    elif tecla == ord('5'): filtro_actual, nombre_filtro = "sepia","Sepia"
    elif tecla == ord('6'): filtro_actual, nombre_filtro = "invertir","Invertir"
    elif tecla == ord('7'): filtro_actual, nombre_filtro = "canny","Canny"
    elif tecla == ord('8'): filtro_actual, nombre_filtro = "blur","Blur"
    elif tecla == ord('9'): filtro_actual, nombre_filtro = "caricatura","Caricatura"
    elif tecla == ord('p'): filtro_actual, nombre_filtro = "pixel","Pixel Art"

    # 📸 Guardar foto
    elif tecla == ord('s'):
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"foto_{nombre_filtro}_{timestamp}.jpg"
        cv2.imwrite(filename, frame_filtrado)
        print(f"💾 Guardado: {filename}")

    # 🚪 Salir con 'q' o ESC
    elif tecla == ord('q') or tecla == 27:
        print("👋 Cerrando cámara...")
        break

# ==============================
# 📌 Liberar recursos
# ==============================
cap.release()
cv2.destroyAllWindows()
